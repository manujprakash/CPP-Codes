#include <bits/stdc++.h>
using namespace std;
 

void FL(int a[],int n,int x)
{
    int f=-1,l=-1;
    for(int i=0;i<n;i++) 
    {
        if(x!=a[i])
            continue;
        if(f==-1)
            f=i;
        l=i;
    }
    if(f!=-1)
        cout<<"First Occurrence = "<<f<<"\nLast Occurrence = "<<l;
    else
        cout<<"Not Found";
}
 

int main()
{
    int a[]={1,2,2,2,2,3,4,7,8,8};
    int n=sizeof(a)/sizeof(int);
    int x=8;
    FL(a,n,x);
    return 0;
}
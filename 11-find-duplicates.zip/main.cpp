#include <bits/stdc++.h>
using namespace std;
 
int main()
{
    int a[]={0,4,3,2,7,8,2,3,1};
    int an=sizeof(a)/sizeof(a[0]);
    for (int i=0;i<an;i++) 
    {
        a[a[i]%an]=a[a[i]%an]+an;
    }
    cout << "The repeating elements are : " << endl;
    for (int i=0;i<an;i++) 
    {
        if (a[i]>=an*2) 
        {
            cout << i << " " << endl;
        }
    }
    return 0;
}
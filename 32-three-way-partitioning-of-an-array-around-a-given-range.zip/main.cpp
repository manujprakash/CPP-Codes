#include<iostream>
using namespace std;
 

void P(int a[],int n,int l,int h)
{

    int s=0,e=n-1;
 

    for(int i=0;i<=e;)
    {

        if (a[i]<l)
        {

          if(i==s)
          {
            s++;
            i++;
          }
          else
            swap(a[i++],a[s++]);
        }

        else if(a[i]>h)
            swap(a[i],a[e--]);
 
        else
            i++;
    }
}
 

int main()
{
    int a[]={1,14,5,20,4,2,54,20,87,98,3,1,32};
    int n=sizeof(a)/sizeof(a[0]);
 
    P(a,n,10,20);
 
    cout<<"Modified array \n";
    for (int i=0;i<n;i++)
        cout<<a[i]<<" ";
}
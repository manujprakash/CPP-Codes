# include <iostream>
using namespace std;
 
void r(int a[], int n)
{
    int x=a[n-1],i;
    for (i=n-1;i>0;i--)
    a[i]=a[i-1];
    a[0]=x;
}
int main()
{
    int a[]={1, 2, 3, 4, 5};
    int i;
    int n=sizeof(a)/sizeof(a[0]);
 
    cout << "Given array is \n";
    for(i=0;i<n;i++)
        cout << a[i] << ' ';
 
    r(a,n);
 
    cout << "\nRotated array is\n";
    for(i=0;i<n;i++)
        cout<<a[i]<<' ';

    return 0;
}
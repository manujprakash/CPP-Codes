#include <bits/stdc++.h>
using namespace std;
  
 
bool N(int a[],int n,int sum) 
{

    for (int i=0;i<n-2;i++)
    { 
  
        for (int j=i+1;j<n-1;j++)
        { 
  
            for (int k=j+1;k<n;k++)
            { 
                if (a[i]+a[j]+a[k]==sum)
                { 
                    cout<<"Triplet is "<<a[i]<<", "<<a[j] <<", "<<a[k]; 
                    return true; 
                } 
            } 
        } 
    } 
  
    return false; 
} 

int main() 
{ 
    int a[]={1,4,45,6,10,8}; 
    int sum=22; 
    int n=sizeof(a)/sizeof(a[0]); 
    N(a,n,sum); 
    return 0; 
} 
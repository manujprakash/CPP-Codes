#include <bits/stdc++.h>
using namespace std;
 

bool B(string ex)
{ 
    stack<char>temp;
        for(int i=0;i<ex.length();i++)
        {
            if(temp.empty())
            {
                temp.push(ex[i]);
            }
            else if((temp.top()=='('&& ex[i]==')')||(temp.top()=='{'&&ex[i]=='}')||(temp.top()=='[' && ex[i]==']'))
            {
                temp.pop();
            }
            else
            {
                temp.push(ex[i]);
            }
        }
        if(temp.empty())
        {
            return true;
        }
        return false;
}
 

int main()
{
    string ex ="{()}[]";
 

    if (B(ex))
        cout<<"Balanced";
    else
        cout<<"Not Balanced";
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
 

#define R 4
#define C 4
 

 
int m(int row[])
{

    stack<int>r;
 
    int tv; 
 
    int ma=0;

 
    int area=0;
 

    int i=0;
    while (i<C) 
    {

        if (r.empty()||row[r.top()]<=row[i])
            r.push(i++);
 
        else 
        {

            tv=row[r.top()];
            r.pop();
            area=tv*i;
 
            if(!r.empty())
                area=tv*(i-r.top()-1);
            ma=max(area,ma);
        }
    }
 

    while(!r.empty()) 
    {
        tv=row[r.top()];
        r.pop();
        area=tv*i;
        if (!r.empty())
            area=tv*(i-r.top()-1);
 
        ma=max(area,ma);
    }
    return ma;
}
 

int mr(int A[][C])
{

    int r=m(A[0]);
 

    for(int i=1;i<R;i++) 
    {
 
        for(int j=0;j<C;j++)
 

            if(A[i][j])
                A[i][j]+=A[i-1][j];
 

        r=max(r,m(A[i]));
    }
 
    return r;
}
 

int main()
{
    int A[][C]=
    {
        {0,1,1,0},
        {1,1,1,1},
        {1,1,1,1},
        {1,1,0,0},
    };
 
    cout<<"Area of maximum rectangle is "<< mr(A);
 
    return 0;
}
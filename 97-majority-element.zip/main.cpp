#include <bits/stdc++.h>
using namespace std;
  

void M(int a[],int n)
{
    int max=0;
    int index=-1;
    for(int i=0;i<n;i++) 
    {
        int count=0;
        for(int j=0;j<n;j++) 
        {
            if(a[i]==a[j])
                count++;
        }
  

        if(count>max) 
        {
            max=count;
            index=i;
        }
    }
  

    if(max>n/2)
        cout<<a[index]<<endl;
  
    else
        cout<<"No Majority Element"<<endl;
}
  

int main()
{
    int a[]={1,1,2,1,3,5,1};
    int n=sizeof(a)/sizeof(a[0]);
  

    M(a,n);
  
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
 
bool sub(int a[],int n)
{
    unordered_set<int>sumSet;
 

    int sum=0;
    for(int i= 0;i<n;i++)
    {
        sum+=a[i];
 

        if(sum==0||sumSet.find(sum)!=sumSet.end())
            return true;
 
        sumSet.insert(sum);
    }
    return false;
}
 

int main()
{
    int a[]={-3,2,3,1,6};
    int n=sizeof(a)/sizeof(a[0]);
    if(sub(a,n))
        cout<<"Found a subarray with 0 sum";
    else
        cout<<"No Such Sub Array Exists!";
    return 0;
}
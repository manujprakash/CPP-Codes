#include<iostream> 
using namespace std; 
#define m 3
#define n 3
void floodFill(int a[][n], int x, int y, int prevC, int newC)
{ 
    if(x<0 || x>=m || y<0 || y>=n) 
        return; 
    if(a[x][y] != prevC) 
        return; 
    if(a[x][y] == newC)  
        return;  
    a[x][y] = newC; 
    floodFill(a, x+1, y, prevC, newC); 
    floodFill(a, x-1, y, prevC, newC); 
    floodFill(a, x, y+1, prevC, newC); 
    floodFill(a, x, y-1, prevC, newC); 
} 
void Fill(int a[][n], int x, int y, int color)
{ 
    int prevColor = a[x][y]; 
    floodFill(a, x, y, prevColor, color); 
} 
int main()
{ 
    int a[m][n] = {{1, 1, 1}, 
                   {1, 1, 0}, 
                   {1, 0, 1},
                  }; 
    int x = 1, y = 1, color = 2; 
    Fill(a, x, y, color); 
    for(int i=0; i<m; i++)
    { 
        cout<<"[ ";
        for (int j=0; j<m; j++) 
           cout<<a[i][j]<<" "; 
        cout<<"]\n"; 
    } 
}

#include <bits/stdc++.h>
using namespace std;
 

int countBits(int a)
{
    int count=0;
    while(a) 
    {
        if(a&1)
            count+=1;
        a=a>>1;
    }
    return count;
}
 

void Sort(int a[],int aux[],int n)
{
    for (int i=1;i<n;i++) 
    {

        int key1=aux[i];
        int key2=a[i];
        int j=i-1;
 

        while(j>=0&&aux[j]<key1) 
        {
            aux[j+1]=aux[j];
            a[j+1]=a[j];
            j=j-1;
        }
        aux[j+1]=key1;
        a[j+1]=key2;
    }
}
 

void Count(int a[],int n)
{

    int aux[n];
    for(int i=0;i<n;i++)
        aux[i]=countBits(a[i]);
 
 
    Sort(a,aux,n);
}
 

void print(int a[],int n)
{
    for(int i=0;i<n;i++)
        cout<<a[i]<< " ";
}
 

int main()
{
    int a[]={1,2,3,4,5,6};
    int n=sizeof(a)/sizeof(a[0]);
    Count(a,n);
    print(a,n);
    return 0;
}
#include <assert.h>
#include <iostream>
using namespace std;
 

void rr(int a[],int n,int oop,int c)
{
    char tmp=a[c];
    for (int i=c;i>oop;i--)
        a[i]=a[i-1];
        a[oop]=tmp;
}
 
void ra(int a[],int n)
{
    int oop=-1;
 
    for (int i=0;i<n;i++)
    {
        if (oop>=0)
        {

            if (((a[i]>=0) && (a[oop]<0))
                || ((a[i]<0)
                    &&(a[oop]>=0)))
            {
                rr(a,n,oop,i);

                if (i-oop>=2)
                    oop=oop+2;
                else
                    oop=-1;
            }
        }
 

        if (oop==-1) 
        {

            if (((a[i]>=0) && (!(i&0x01)))
                || ((a[i]<0) && (i&0x01))) 
                {
                oop=i;
            }
        }
    }
}
 

void pa(int a[],int n)
{
    for (int i=0;i<n;i++)
        cout<<a[i]<<" ";
        cout<<endl;
}
 
int main()
{
     
    int a[]={-5,-2,5,2,4,7,1,8,0,-8};
    int n = sizeof(a) / sizeof(a[0]);
 
    cout << "Given array is ";
    pa(a,n);
    ra(a,n);
 
    cout<<"Rearranged array is \n";
    pa(a,n);
 
    return 0;
}
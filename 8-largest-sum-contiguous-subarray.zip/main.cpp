#include<iostream>
#include<climits>
using namespace std;
 
int M(int a[], int n)
{
    int maxsf=INT_MIN,maxeh=0;
 
    for (int i=0;i<n;i++)
    {
        maxeh=maxeh+a[i];
        if (maxsf<maxeh)
            maxsf=maxeh;
 
        if (maxeh<0)
            maxeh=0;
    }
    return maxsf;
}
int main()
{
    int a[]={-2, -3, 4, -1, -2, 1, 5, -3};
    int n = sizeof(a)/sizeof(a[0]);
    int ms=M(a,n);
    cout<<"Maximum contiguous sum is "<<ms;
    return 0;
}
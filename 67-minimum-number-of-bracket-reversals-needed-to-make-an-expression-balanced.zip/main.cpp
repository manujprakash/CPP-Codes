#include <bits/stdc++.h>
using namespace std;
  

int R(string ex)
{
    int len=ex.length();
  

    if(len%2)
        return-1;
  

    stack<char>s;
    for(int i=0;i<len;i++) 
    {
        if(ex[i]=='}'&&!s.empty()) 
        {
            if (s.top()=='{')
                s.pop();
            else
                s.push(ex[i]);
        }
        else
            s.push(ex[i]);
    }
  

    int r=s.size();
  

    int n=0;
    while(!s.empty()&&s.top()=='{') 
    {
        s.pop();
        n++;
    }
 

    return(r/2+n%2);
}
  

int main()
{
    string ex="}}{{";
    cout<<R(ex);
    return 0;
}
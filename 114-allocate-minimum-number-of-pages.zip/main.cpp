#include <bits/stdc++.h>
using namespace std;

bool P(int a[],int n,int m,int curr_min)
{
    int sR=1;
    int curr_sum=0;
 

    for(int i=0;i<n;i++) 
    {

        if(a[i]>curr_min)
            return false;
 
 
        if(curr_sum+a[i]>curr_min) 
        {
        
            sR++;
 
         
            curr_sum=a[i];
 
      
            if(sR>m)
                return false;
        }
 
   
        else
            curr_sum+=a[i];
    }
    return true;
}
 

int find(int a[],int n,int m)
{
    long long sum=0;
 

    if(n<m)
        return -1;
 
 
    for(int i=0;i<n;i++)
        sum+=a[i];
 
 
    int start=0,end=sum;
    int result=INT_MAX;
 

    while(start<=end) 
    {
    
        int mid=(start+end)/2;
        if(P(a,n,m,mid)) 
        {
  
            result=mid;
 

            end=mid-1;
        }
 
        else
 
            start=mid+1;
    }
 

    return result;
}
 

int main()
{

    int a[]={12,34,67,90};
    int n=sizeof a/sizeof a[0];
    int m=2;
 
    cout<<"Minimum number of pages = "<<find(a,n,m)<<endl;
    return 0;
}
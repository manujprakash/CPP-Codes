# include <bits/stdc++.h>
using namespace std;

int p(int a[],int n)
{
    int b=a[0],m=0;
    for(int i=1;i<n;i++)
    {
        if(b>a[i])
          b=a[i];
        else if(a[i]-b>m)
          m=a[i]-b;
    }
    return m;
}

int main()
{
    int a[]={7,1,5,6,4};
    int n=sizeof(a)/sizeof(a[0]);
    int m=p(a,n);
    cout<<m<<endl;
    return 0;
}
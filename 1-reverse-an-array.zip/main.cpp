#include <bits/stdc++.h>
using namespace std;
void reva(int a[],int s,int e)
{
    while(s<e)
    {
        int t=a[s];
        a[s]=a[e];
        a[e]=t;
        s++;
        e--;
    }
}
void printa(int a[],int size)
{
    for(int i=0;i<size;i++)
    cout<<a[i]<<" ";
    cout<<endl;
}
int main()
{
    int a[]={1,2,3,4,5,6};
    int n=sizeof(a)/sizeof(a[0]);
    printa(a,n);
    reva(a,0,n-1);
    printf("reversed array is\n");
    printa(a,n);
    return 0;
}
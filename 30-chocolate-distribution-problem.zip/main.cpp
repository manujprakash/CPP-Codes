#include <bits/stdc++.h>
using namespace std;
  

int D(int a[],int n,int m)
{

    if(m==0||n==0)
        return 0;
  
    sort(a,a+n);
  
    if(n<m)
        return -1;
  

    int min_diff=INT_MAX;
  
  
    for (int i=0;i+m-1<n;i++) 
    {
        int diff=a[i+m-1]-a[i];
        if (diff<min_diff)
            min_diff=diff;
    }
    return min_diff;
}
  
int main()
{
    int a[]={12,4,7,9,2,2325,41,30,40,28,42,30,44,48,43,50};
    int m=7;
    int n=sizeof(a)/sizeof(a[0]);
    cout<<"Minimum difference is "<<D(a,n,m);
    return 0;
}
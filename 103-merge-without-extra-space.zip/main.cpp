#include<bits/stdc++.h>
using namespace std;
void merge(int a1[],int a2[],int n,int m) 
{
    int a3[n+m];
    int k=0;
    for(int i=0;i<n;i++) 
    {
      a3[k++]=a1[i];
    }
    for(int i=0;i<m;i++) 
    {
      a3[k++]=a2[i];
    }
    sort(a3,a3+m+n);
    k=0;
    for(int i=0;i<n;i++) 
    {
      a1[i]=a3[k++];
    }
    for(int i=0;i<m;i++) 
    {
      a2[i]=a3[k++];
    }

  }
int main() 
{
    int a1[]={1,4,7,8,10};
	int a2[]={2,3,9};
    cout<<"Before merge:"<<endl;
    for(int i=0;i<5;i++) 
    {
      cout<<a1[i]<<" ";
    }
    cout<<endl;
    for(int i= 0;i<3;i++) 
    {
      cout<<a2[i]<<" ";
    }
    cout<<endl;
    merge(a1,a2,5,3);
    cout<<"After merge:"<<endl;
    for(int i=0;i<5;i++) 
    {
      cout<<a1[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<3;i++) 
    {
      cout<<a2[i]<<" ";
    }

  }
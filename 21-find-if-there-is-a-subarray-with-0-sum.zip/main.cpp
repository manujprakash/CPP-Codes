# include <bits/stdc++.h>
using namespace std;

bool SA(int a[],int n)
{
    unordered_set<int> sumSet;
    int s=0;
    for(int i=0;i<n;i++)
    {
        s+=a[i];
        if(s==0||sumSet.find(s)!=sumSet.end())
         return true;
        sumSet.insert(s);
    }
    return false;
}

int main()
{
    int a[]={-3,2,3,1,6};
    int n=sizeof(a)/sizeof(a[0]);
    if(SA(a,n))
     cout<<"found";
    else
     cout<<"not found";
    return 0;
}























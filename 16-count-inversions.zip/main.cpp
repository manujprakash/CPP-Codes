# include <bits/stdc++.h>
using namespace std;
int ic(int a[],int n)
{
    int c=0;
    for(int i=0;i<n-1;i++)
        for(int j=i+1;j<n;j++)
            if(a[i]>a[j])
                c++;
    return c;
}

int main()
{
    int a[]={1,20,6,4,5};
    int n=sizeof(a)/sizeof(a[0]);
    cout<<"Number of inversion are "<<ic(a,n);
    return 0;
}
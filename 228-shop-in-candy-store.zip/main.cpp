#include<bits/stdc++.h>
using namespace std;
int main()
 {
	int t;
	cin>>t;
	while(t--)
	{
	  int n,k,n1,n2=0;
	  cin>>n>>k;
	  int arr[n];
	  for(int k=0;k<n;k++)
	  {
	      cin>>arr[k];
	  }
	  long int sum1=0,sum2=0;
	  n1=n;
	  int i=0,j=n-1;
	  sort(arr,arr+n);
	  while(i<n1)
	  {
	      sum1=sum1+arr[i];
	      n1=n1-k;
	      i++;
	  }
	    while(j>=n2)
	    {
	        sum2=sum2+arr[j];
	        n2=n2+k;
	        j--;
	    }
	    cout<<sum1<<" "<<sum2<<endl;
	}
	return 0;
}
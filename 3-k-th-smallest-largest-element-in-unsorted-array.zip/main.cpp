# include <bits/stdc++.h>
using namespace std;

int ksmall(int a[],int n,int k)
{
    sort(a,a+n);
    return a[k-1];
}
int klarg(int a[],int n,int k)
{
    sort(a,a+n,greater<int>());
    //for(int i=0;i<k;i++)
    return a[k-1];
        
}
int main()
{
    int a[]={12,3,5,7,9};
    int n=sizeof(a)/sizeof(a[0]);
    int k=2;
    cout<<"kth smallest element is "
        <<ksmall(a,n,k);
    cout<<" kth largest element is "
        <<klarg(a,n,k);    
        return 0;
}
# include <bits/stdc++.h>
using namespace std;

int F(int n)
{
    if(n==0)
     return 1;
    return n*F(n-1);
}
int main()
{
    int n=5;
    cout<<"Factorial is "<<F(n)<<endl;
    return 0;
}
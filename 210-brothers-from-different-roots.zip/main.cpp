void inorder(Node *root, vector<int> &v)
{
    if (!root)
        return;
    inorder(root->left, v);
    v.push_back(root->data);
    inorder(root->right, v);
}
int countPairs(Node *root1, Node *root2, int x)
{
    vector<int> v1, v2;
    inorder(root1, v1);
    inorder(root2, v2);
    int found = 0;
    for (auto ele : v1)
    {
        int complement = x - ele;
        if (find(v2.begin(), v2.end(), complement) != v2.end())
        {
            found++;
        }
    }
    return found;
}
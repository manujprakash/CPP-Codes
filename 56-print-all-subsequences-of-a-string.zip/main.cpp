#include <bits/stdc++.h>
using namespace std;
 

void S(string ip, string op)
{

    if (ip.empty()) 
    {
        cout<<op<<endl;
        return;
    }

    S(ip.substr(1),op+ip[0]);
 

    S(ip.substr(1),op);
}
 

int main()
{

    string op="";
    string ip="abcd";
 
    S(ip,op);
 
    return 0;
}
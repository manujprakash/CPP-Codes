# include<iostream>
using namespace std;
struct p
{
    int min ;
    int max;
};
p mnm(int a[],int n)
{
    struct p mm;
    int i;
    if(n==1)
    {
        mm.max=a[0];
        mm.min=a[0];
        return mm;
    }
    if(a[0]>a[1])
    {
        mm.max=a[0];
        mm.min=a[1];
    }
    else
    {
        mm.max=a[1];
        mm.min=a[0];        
    }
    for(i=2;i<n;i++)
    {
        if(a[i]>mm.max)
          mm.max=a[i];
        else if(a[i]<mm.min)
          mm.min=a[i];
    }
    return mm;
}

int main()
{
    int a[]={1000,11,445,1,330,3000};
    int a_size=6;
    struct p mm=mnm(a,a_size);
    cout<<"minimum element is"
        <<mm.min<<endl;    
    cout<<"maximum element is"
        <<mm.max<<endl;
    return 0;
}













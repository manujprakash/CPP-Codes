# include <iostream>
using namespace std;
 

int S(int a[],int n,int x)
{

     int min=n+1;
 

     for (int i=0;i<n;i++)
     {

          int c=a[i];
 
          if (c>x) 
           return 1;
 

          for (int e=i+1;e<n;e++)
          {

              c+=a[e];
 
              if (c>x && (e-i+1)<min)
                 min=(e-i+1);
          }
     }
     return min;
}

int main()
{
    int a1[]={1,4,45,6,10,19};
    int x=51;
    int n1=sizeof(a1)/sizeof(a1[0]);
    int r1=S(a1,n1,x);
    (r1==n1+1)?cout<<"Not possible\n":cout<<r1<<endl;
 
    int a2[]={1,10,5,2,7};
    int n2=sizeof(a2)/sizeof(a2[0]);
    x =9;
    int r2=S(a2,n2,x);
    (r2==n2+1)?cout<<"Not possible\n":cout<<r2<<endl;
 
    int a3[]={1,11,100,1,0,200,3,2,1,250};
    int n3=sizeof(a3)/sizeof(a3[0]);
    x=280;
    int r3=S(a3,n3,x);
    (r3==n3+1)?cout<<"Not possible\n":cout<<r3<<endl;
 
    return 0;
}
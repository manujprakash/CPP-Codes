#include <bits/stdc++.h>
using namespace std;
  

int bs(int a[],int low,int high,int k)
{
    if (high<low)
        return-1;
  
    int mid=(low+high)/2; 
    if(k==a[mid])
        return mid;
  
    if(k>a[mid])
        return bs(a,(mid+1),high,k);
  
   
    return bs(a,low,(mid-1),k);
}
  

int P(int a[],int low,int high)
{
    
    if(high<low)
        return-1;
    if(high==low)
        return low;
  
    int mid=(low+high)/2;
    if(mid<high&&a[mid]>a[mid+1])
        return mid;
  
    if(mid>low&&a[mid]<a[mid-1])
        return(mid-1);
  
    if(a[low]>=a[mid])
        return P(a,low,mid-1);
  
    return P(a,mid+1,high);
}
  

int pbs(int a[],int n,int k)
{
    int pivot=P(a,0,n-1);

    if (pivot==-1)
        return bs(a,0,n-1,k);

    if(a[pivot]==k)
        return pivot;
  
    if(a[0]<=k)
        return bs(a,0,pivot-1,k);
  
    return bs(a,pivot+1,n-1,k);
}
  

int main()
{

    int a[]={5,6,7,8,9,10,1,2,3};
    int n=sizeof(a)/sizeof(a[0]);
    int key=3;
  

    cout<<"Index of the element is : "<< pbs(a,n,key);
  
    return 0;
}
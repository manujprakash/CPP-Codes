# include <bits/stdc++.h>
using namespace std;
int mj(int a[],int n)
{
    if (n==1)
      return 0;
    int r=INT_MAX;
    for(int i=n-2;i>=0;i--)
    {
        if(i+a[i]>=n-1)
        {
            int s=mj(a,i+1);
            if(s!=INT_MAX)
              r=min(r,s+1);
        }
    }
    return r;
}

int main()
{
    int a[]={1,3,6,3,2,3,6,8,9,5};
    int n=sizeof(a)/sizeof(a[0]);
    cout<<"min number of jumps to 0";
    cout<<"reach the end is "<<mj(a,n);
    return 0;
}














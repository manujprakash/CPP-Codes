#include<bits/stdc++.h>
using namespace std;

    bool P(int N)
    {
        string str=""+N;
        int len=str.length();
        for(int i=0;i<len/2;i++) 
        {
            if(str[i]!=str[len-1-i])
                return false;
        }
        return true;
    }
 

    bool PA(int a[],int n)
    {
        for(int i=0;i<n;i++) 
        {
            bool ans=P(a[i]);
            if(ans==false)
                return false;
        }
        return true;
    }
 

    int main()
    {
        int a[]={121,131,20};
 
        int n=sizeof(a)/sizeof(a[0]);
 
        bool r=PA(a,n);
        if(r==true)
            cout<<"Array is a PalinArray";
        else
            cout<<"Array is not a PalinArray";
    }
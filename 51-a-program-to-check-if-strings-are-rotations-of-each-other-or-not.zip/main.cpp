# include <bits/stdc++.h>
using namespace std;

bool R(string s1,string s2)
{
    if(s1.length()!=s2.length())
        return false;
    string t=s1+s2;
    return (t.find(s2)!=string::npos);
}
int main()
{
    string s1="aacd",s2="acda";
    if(R(s1,s2))
        printf("Strings are rotations of each other");
    else
        printf("Strings are not rotations of each other");
    return 0;
}
#include <bits/stdc++.h>

using namespace std;
bool isC(vector<int>inp,int dist,int cows) 
{
  int n=inp.size();
  int k=inp[0];
  cows--;
  for(int i=1;i<n;i++) 
  {
    if(inp[i]-k>=dist) 
    {
      cows--;
      if(!cows) 
      {
        return true;
      }
      k=inp[i];
    }
  }
  return false;
}
int main() 
{
  int n=5,m=3;
  vector<int>inp{1,2,8,4,9};
  sort(inp.begin(), inp.end());
  int maxD=inp[n-1]-inp[0];
  int ans=INT_MIN;
  for (int d=1;d<=maxD;d++) 
  {
    bool possible=isC(inp,d,m);
    if (possible) 
    {
      ans=max(ans, d);
    }
  }
  cout << "The largest minimum distance is " << ans << '\n';
}
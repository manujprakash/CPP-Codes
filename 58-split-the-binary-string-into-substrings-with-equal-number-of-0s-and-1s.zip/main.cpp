#include <bits/stdc++.h>
using namespace std;
 

int S(string str,int n)
{
 

    int c0=0,c1=0;
 

    int cnt=0;
    for(int i=0;i<n;i++) 
    {
        if(str[i]=='0') 
        {
            c0++;
        }
        else 
        {
            c1++;
        }
        if(c0==c1) 
        {
            cnt++;
        }
    }
 

    if (c0!=c1) 
    {
        return -1;
    }
 
    return cnt;
}
 

int main()
{
    string str="0100110101";
    int n=str.length();
 
    cout<<S(str,n);
 
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
 
#define ARRAY_SIZE(a)(sizeof(a)/sizeof(*a))
 

int is(string n, int row,int col,string hay[],int row_max,int col_max,int xx)
{
    int f=0;
 
    if(row>=0&&row<=row_max&&col>=0&&col<=col_max&&n[xx]==hay[row][col])
    {
        char match=n[xx];
        xx+=1;
 
        hay[row][col]=0;
 
        if(n[xx]==0)
        {
            f=1;
        }
        else
        {

            f+=is(n,row,col+1,hay,row_max,col_max,xx);
            f+=is(n,row,col-1,hay,row_max,col_max,xx);
            f+=is(n,row+1,col,hay,row_max,col_max,xx);
            f+=is(n,row-1,col,hay,row_max,col_max,xx);
        }
        hay[row][col]=match;
    }
    return f;
}
 

int ss(string n,int row,int col,string str[],int row_count,int col_count)
{
    int f=0;
    int r,c;
 
    for(r=0;r<row_count;++r)
    {
        for(c=0;c<col_count;++c)
        {
            f+=is(n,r,c,str,row_count-1,col_count-1,0);
        }
    }
    return f;
}
 

int main()
{
    string n="MAGIC";
    string input[]={"BBABBM",
                       "CBMBBA",
                       "IBABBG",
                       "GOZBBI",
                       "ABBBBC",
                       "MCIGAM"};
    string str[ARRAY_SIZE(input)];
    int i;
    for(i=0;i<ARRAY_SIZE(input);++i)
    {
        str[i]=input[i];
    }
 
    cout<<"count:"<<ss(n,0,0,str,ARRAY_SIZE(str),str[0].size()) << endl;
    return 0;
}
#include <iostream>
#include <string>
 
#define R 3
#define C 3
using namespace std;
 

void U(string a[R][C],int m,int n,string op[R])
{
    
    op[m]=a[m][n];
 

    if(m==R-1)
    {
        for(int i=0;i<R;i++)
           cout<<op[i]<<" ";
        cout<<endl;
        return;
    }
 
  
    for(int i=0;i<C;i++)
       if(a[m+1][i]!="")
          U(a,m+1,i,op);
}
 

void print(string a[R][C])
{

   string op[R];
 

   for(int i=0;i<C;i++)
     if(a[0][i]!="")
        U(a,0,i,op);
}
 

int main()
{
   string a[R][C]={{"you","we"},
                   {"have","are"},
                   {"sleep","eat","drink"}};
 
   print(a);
 
   return 0;
}
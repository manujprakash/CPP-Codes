#include <bits/stdc++.h>
using namespace std;
 
int Memo(int words[], int n, int length,int wordIndex, int remLength,vector<vector<int> > memo);
 
int square(int n) 
{ 
    return n*n; 
    
}
 
int Util(int words[], int n, int length,int wordIndex, int remLength,vector<vector<int> > memo)
{
 

    if (wordIndex==n-1) 
    {
        memo[wordIndex][remLength]
            = words[wordIndex]<remLength
                  ? 0
                  : square(remLength);
        return memo[wordIndex][remLength];
    }
 
    int currWord=words[wordIndex];
   
    if (currWord<remLength) 
    {
        return min(Memo(
                       words, n, length, wordIndex + 1,
                       remLength == length
                           ? remLength - currWord
                           : remLength - currWord - 1,
                       memo),
 
                   square(remLength)
                       + Memo(
                           words, n, length, wordIndex + 1,
                           length - currWord, memo));
    }
    else {
        
        return square(remLength)
               + Memo(
                   words, n, length, wordIndex + 1,
                   length - currWord, memo);
    }
}
 
int Memo(int words[], int n, int length,
                           int wordIndex, int remLength,
                           vector<vector<int> > memo)
{
    if (memo[wordIndex][remLength] != -1) 
    {
        return memo[wordIndex][remLength];
    }
 
    memo[wordIndex][remLength] =Util(
        words, n, length, wordIndex, remLength, memo);
    return memo[wordIndex][remLength];
}
 
int solve(int words[], int n, int k)
{
 
    vector<vector<int> > memo(n, vector<int>(k + 1, -1));
 
    return Memo(words, n, k, 0, k, memo);
}
int main()
{
    int words[] = { 3, 2, 2, 5 };
    int n = sizeof(words) / sizeof(words[0]);
    int k = 6;
 
    cout << solve(words, n, k);
    return 0;
}
# include <bits/stdc++.h>
using namespace std;

int L(int A[],int n)
{
    int a=0,c=0;
    sort(A,A+n);
    vector<int>v;
    v.push_back(A[0]);
    for(int i=1;i<n;i++)
    {
        if(A[i]!=A[i-1])
        v.push_back(A[i]);
    }
    for(int i=0;i<v.size();i++)
    {
        if(i>0&&v[i]==v[i-1]+1)
        c++;
        else
        c=1;
        a=max(a,c);
    }
    return a;
}

int main()
{
int a[]={1,2,2,3};
int n=sizeof(a)/sizeof(a[0]);
cout<<"Length is "<<L(a,n);
return 0;
}
# include <bits/stdc++.h>
using namespace std;

int P(int a[],int n)
{
    int r=a[0];
    for(int i=0;i<n;i++)
    {
        int m=a[i];
        for(int j=i+1;j<n;j++)
        {
            r=max(r,m);
            m*=a[j];
        }
        r=max(r,m);
    }
    return r;
}
int main()
{
    int a[]={1,-2,-3,0,7,-8,-2};
    int n=sizeof(a)/sizeof(a[0]);
    cout<<"Max Product is "<<P(a,n);
    return 0;
}




#include <bits/stdc++.h>
using namespace std;
int MD(int a[],int n,int k)
{
    sort(a,a+n);
    int ans=a[n-1]-a[0];
    int tmin, tmax;
    tmin=a[0];
    tmax=a[n-1];
 
    for (int i = 1;i<n;i++) 
    {
        if(a[i]-k<0);
        tmin=min(a[0]+k,a[i]-k);
        tmax=max(a[i-1]+k,a[n-1]-k);                                                    // subtract k from whole array
        ans=min(ans,tmax-tmin);
    }
    return ans;
}
int main()
{
    int k=6,n=6;
    int a[n]={7, 4, 8, 8, 8, 9};
    int ans=MD(a,n,k);
    cout << ans;
}
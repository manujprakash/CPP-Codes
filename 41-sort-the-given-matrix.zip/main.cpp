#include <bits/stdc++.h>
using namespace std;
#define N 3
#define M 3
 

void s(int d[N][M],int r,int c)
{
 

    int s=r*c;
 

    for(int i=0;i<s;i++)
    {
        for(int j=0;j<s-1;j++)
        {
 

            if(d[j/c][j%c]>d[(j+1)/c][(j+1)%c])
            {

                int temp=d[j/c][j%c];
                d[j/c][j%c]=d[(j+1)/c][(j+1)%c];
                d[(j+1)/c][(j+1)%c]=temp;
            }
        }
    }
}
 
void p(int mat[N][M],int r,int c)
{
 

    for(int i=0;i<r;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<mat[i][j]<< " ";
        }
        cout<<endl;
    }
}
 
int main()
{
    int mat[N][M]={{5,4,7},
                   {1,3,8},
                   {2,9,6}};
         
    int r=N;
    int c=M;
 

    s(mat,r,c);
 

    p(mat,r,c);
    return 0;
}

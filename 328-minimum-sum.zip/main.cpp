#include <bits/stdc++.h>
using namespace std;
int solve(int arr[], int N)
{
    sort(arr, arr + N);
    int a = 0, b = 0;
    for (int i = 0; i < N; i++) 
    {
        if (i & 1)
            a = a * 10 + arr[i];
        else
            b = b * 10 + arr[i];
    }
    return a + b;
}
int main()
{
    int arr[] = { 6, 8, 4, 5, 2, 3 };
    int N = sizeof(arr) / sizeof(arr[0]);
    cout << "Sum is " << solve(arr, N);
    return 0;
}
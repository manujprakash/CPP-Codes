#include <bits/stdc++.h>
#include <string.h>
using namespace std;
 

class Word 
{
public:
    char*str; 
    int index; 
};
 

class DupArray 
{
public:
    Word*array;
    int size; 
};
 

DupArray*createDupArray(char*str[],int size)
{
    
    DupArray*dupArray=new DupArray();
    dupArray->size=size;
    dupArray->array=new Word[(dupArray->size*sizeof(Word))];
 

    int i;
    for(i=0;i<size;++i) 
    {
        dupArray->array[i].index=i;
        dupArray->array[i].str=new char[(strlen(str[i])+1)];
        strcpy(dupArray->array[i].str, str[i]);
    }
 
    return dupArray;
}
 

int compChar(const void*a,const void* b)
{
    return*(char*)a-*(char*)b;
}
 

int compStr(const void*a,const void* b)
{
    Word*a1=(Word*)a;
    Word*b1=(Word*)b;
    return strcmp(a1->str,b1->str);
}
 

void printAnagramsTogether(char*wordArr[],int size)
{

    DupArray*dupArray=createDupArray(wordArr, size);
 
    int i;
    for(i=0;i<size;++i)
        qsort(dupArray->array[i].str,strlen(dupArray->array[i].str),sizeof(char),compChar);
 

    qsort(dupArray->array,size,sizeof(dupArray->array[0]),compStr);
 

    for(i=0;i<size;++i)
        cout<<wordArr[dupArray->array[i].index]<<" ";
}
 

int main()
{
    char*wordArr[]={"cat","dog","tac","god","act"};
    int size=sizeof(wordArr)/sizeof(wordArr[0]);
    printAnagramsTogether(wordArr,size);
    return 0;
}
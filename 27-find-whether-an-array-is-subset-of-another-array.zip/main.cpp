#include <bits/stdc++.h>
 

bool S(int a1[],int a2[],int m,int n)
{
    int i=0;
    int j=0;
    for(i=0;i<n;i++) 
    {
        for(j=0;j<m;j++) 
        {
            if(a2[i]==a1[j])
                break;
        }
 
        if (j==m)
            return 0;
    }
 
    return 1;
}
 
int main()
{
    int a1[]={11,1,13,21,3,7};
    int a2[]={11,3,7,1};
 
    int m=sizeof(a1)/sizeof(a1[0]);
    int n=sizeof(a2)/sizeof(a2[0]);
 
    if (S(a1,a2,m,n))
        printf("a2 is subset of a1");
    else
        printf("a2 is not a subset of a1");
 
    getchar();
    return 0;
}
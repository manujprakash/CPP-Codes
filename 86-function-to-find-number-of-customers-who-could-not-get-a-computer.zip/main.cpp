#include<iostream>
#include<cstring>
using namespace std;
 
#define MAX_CHAR 26
 

int CS(int n,const char*seq)
{

    char seen[MAX_CHAR]={0};
 

    int res=0;
 
    int occupied=0;

    for(int i=0;seq[i];i++)
    {
        
        int ind=seq[i]-'A';
 
  
        if(seen[ind]==0)
        {
          
            seen[ind]=1;
 

            if(occupied<n)
            {
                occupied++;
 
                
                seen[ind]=2;
            }
 
          
            else
                res++;
        }
 
     
        else
        {
    
        if(seen[ind]==2)
            occupied--;
        seen[ind]=0;
        }
    }
    return res;
}
 

int main()
{
    cout<<CS(2,"ABBAJJKZKZ")<<endl;
    cout<<CS(3,"GACCBDDBAGEE")<<endl;
    cout<<CS(3,"GACCBGDDBAEE")<<endl;
    cout<<CS(1,"ABCBCA")<<endl;
    cout<<CS(1,"ABCBCADEED")<<endl;
    return 0;
}
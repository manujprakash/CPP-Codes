#include <iostream>
using namespace std;
 

int C(string &word)
{
    string dict[]={"mobile","samsung","sam","sung","man","mango", "icecream","and","go","i","love","ice","cream"};
    int n=sizeof(dict)/sizeof(dict[0]);
    for(int i=0;i<n;i++)
        if (dict[i].compare(word)==0)
            return true;
    return false;
}
 

void BU(string str,int size,string result);
 

void B(string str)
{

    BU(str, str.size(),"");
}
 

void BU(string str,int n,string result)
{

    for(int i=1;i<=n;i++)
    {
        
        string prefix=str.substr(0, i);
 

        if(C(prefix))
        {
           
            if(i==n)
            {
                
                result+=prefix;
                cout<<result<<endl;
                return;
            }
            BU(str.substr(i,n-i),n-i,result+prefix+" ");
        }
    }     
}
 

int main()
{
   

    cout<<"First Test:\n";
    B("iloveicecreamandmango");
 
    cout<<"\nSecond Test:\n";
    B("ilovesamsungmobile");
    return 0;
}
# include <bits/stdc++.h>
# include <vector>
using namespace std;
void m(vector<int>& a)
{
    sort(a.begin(),a.end());
}
int main()
{
    vector<int> a={-1,-2,-3,4,5,6,-7,8,-9};
    m(a);
    for (int e:a)
    cout<<e<<"     ";
    return 0;
}
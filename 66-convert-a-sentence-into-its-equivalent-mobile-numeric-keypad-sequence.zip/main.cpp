#include <bits/stdc++.h>
using namespace std;
 

string S(string a[],string ip)
{
    string op="";
 

    int n=ip.length();
    for(int i=0;i<n;i++)
    {

        if(ip[i]==' ')
            op=op+"0";
 
        else
        {

            int pos=ip[i]-'A';
            op=op+a[pos];
        }
    }
 

    return op;
}
 

int main()
{
    
    string str[] = {"2","22","222",
                    "3","33","333",
                    "4","44","444",
                    "5","55","555",
                    "6","66","666",
                    "7","77","777","7777",
                    "8","88","888",
                    "9","99","999","9999"
                   };
 
    string ip="GEEKSFORGEEKS";
    cout<<S(str,ip);
    return 0;
}
#include<bits/stdc++.h>
using namespace std;
string gameMax(string S)
{
    int N = S.length();
    vector<int> list;
    int one = 0;
    for(int i = 0; i < N; i++)
    {
        if (S[i] == '1')
        {
            one++;
        }
        else
        {
            if (one != 0)
            {
                list.push_back(one);
            }
            one = 0;
        }
    }
    if (one != 0)
    {
        list.push_back(one);
    }
    sort(list.begin(), list.end(),
         greater<int>());
    int score_1 = 0, score_2 = 0;
    for(int i = 0; i < list.size(); i++)
    {
        if (list[i] % 2 == 1)
        {
            score_1 += list[i];
        }
        else
        {
            score_2 += list[i];
        }
    }
    if (score_1 == score_2)
        return "-1";
    return (score_1 > score_2) ? "Player 1" :"Player 2";
}
int main()
{
    string S = "11111101";
    cout << gameMax(S);
}
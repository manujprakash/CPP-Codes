#include <iostream>
using namespace std;
 
int kth(int a1[],int a2[],int m,int n,int k)
{
    int s1[m+n];
    int i=0,j=0,d=0;
    while(i<m&&j<n)
    {
        if(a1[i]<a2[j])
            s1[d++]=a1[i++];
        else
            s1[d++]=a2[j++];
    }
    while(i<m)
        s1[d++]=a1[i++];
    while(j<n)
        s1[d++]=a2[j++];
    return s1[k-1];
}
 

int main()
{
    int a1[5]={2,3,6,7,9};
    int a2[4]={1,4,8,10};
    int k=5;
    cout<<kth(a1,a2,5,4,k);
    return 0;
}
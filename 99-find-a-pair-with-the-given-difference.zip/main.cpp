#include <bits/stdc++.h>
using namespace std;
 

bool Pair(int a[],int size,int n)
{

    int i=0;
    int j=1;
 

    while(i<size&&j<size)
    {
        if(i!=j&&(a[j]-a[i]==n||a[i]-a[j]==n) )
        {
            cout<<"Pair Found: ("<<a[i]<<", "<<a[j]<<")";
            return true;
        }
        else if(a[j]-a[i]<n)
            j++;
        else
            i++;
    }
 
    cout<<"No such pair";
    return false;
}
 

int main()
{
    int a[]={1,8,30,40,100};
    int size=sizeof(a)/sizeof(a[0]);
    int n=-60;
    Pair(a,size,n);
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
 

char flip(char ch) 
{ return(ch=='0')?'1':'0'; 
    
}
 

int getFlip(string str,char exp)
{
    int flipCount=0;
    for(int i=0;i<str.length();i++) 
    {

        if(str[i]!=exp)
            flipCount++;
 
      
        exp=flip(exp);
    }
    return flipCount;
}
 

int minFlip(string str)
{

    return min(getFlip(str,'0'),
               getFlip(str,'1'));
}
 

int main()
{
    string str="0001010111";
    cout<<minFlip(str);
    return 0;
}
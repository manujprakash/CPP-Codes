#include <bits/stdc++.h>
using namespace std;
 
int ls(int a[],int n)
{
    int i;
    for(i=0;i<n;i++) 
    {
        if(a[i]==i)
            return i;
    }
 

    return -1;
}
 

int main()
{
    int a[]={-10,-1,0,3,10,11,30,50,100};
    int n=sizeof(a)/sizeof(a[0]);
    cout<<"Fixed Point is "<<ls(a,n);
    return 0;
}
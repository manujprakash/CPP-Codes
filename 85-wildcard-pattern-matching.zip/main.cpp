#include <bits/stdc++.h>
using namespace std;
 

bool m(char str[],char pat[],int n,int m)
{

    if(m==0)
        return(n==0);
 

    bool lookup[n+1][m+1];
 

    memset(lookup,false,sizeof(lookup));
 
  
    lookup[0][0]=true;
 

    for(int j=1;j<=m;j++)
        if(pat[j-1]=='*')
            lookup[0][j]=lookup[0][j-1];
 

    for(int i=1;i<=n;i++) 
    {
        for(int j=1;j<=m;j++)
        {

            if(pat[j-1]=='*')
                lookup[i][j]=lookup[i][j-1]||lookup[i-1][j];
 

            else if(pat[j-1]=='?'||str[i-1]==pat[j-1])
                lookup[i][j]=lookup[i-1][j-1];
 

            else
                lookup[i][j]=false;
        }
    }
 
    return lookup[n][m];
}
 
int main()
{
    char str[]="baaabab";
    char pat[]="*****ba*****ab";

 
    if (m(str,pat,strlen(str),strlen(pat)))
        cout<<"Yes"<<endl;
    else
        cout<<"No"<<endl;
 
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
    

int M(int a1[],int a2[],int n,int m) 
{ 
    int i=0;
    int j=0;
    int c; 
    int m1=-1,m2=-1; 

    for(c= 0;c<=(m+n)/2;c++)
    { 
        m2=m1;
        if(i!=n&&j!=m)
        { 
            m1=(a1[i]>a2[j])?a2[j++]:a1[i++]; 
        } 
        else if(i<n)
        { 
            m1=a1[i++]; 
        } 

        else
        { 
            m1=a2[j++]; 
        } 
    } 
 
    if((m+n)%2==1)
    {
        return m1; 
    }
    else
    {
        return(m1+m2)/2;
    } 
} 

int main() 
{ 
    int a1[]={900}; 
    int a2[]={5,8,10,20}; 
    int n1=sizeof(a1)/sizeof(a1[0]); 
    int n2=sizeof(a2)/sizeof(a2[0]); 
    cout<<M(a1,a2,n1,n2);
}
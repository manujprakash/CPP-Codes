#include <bits/stdc++.h>
using namespace std;
  
void p(int a[],int size)
{
    int i;
    cout<<"The repeating element is ";
  
    for(i=0;i<size;i++) 
    {
        if(a[abs(a[i])-1]>0)
            a[abs(a[i])-1]=-a[abs(a[i])-1];
        else
            cout<<abs(a[i])<<"\n";
    }
  
    cout<<"and the missing element is ";
    for(i=0;i<size;i++) 
    {
        if (a[i]>0)
            cout<<(i+1);
    }
}
  

int main()
{
    int a[]={7,3,4,5,5,6,2};
    int n=sizeof(a)/sizeof(a[0]);
    p(a,n);
}
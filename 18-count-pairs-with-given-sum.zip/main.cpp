# include <bits/stdc++.h>
using namespace std;

int C(int a[],int n,int s)
{
    int c=0;
    for(int i=0;i<n;i++)
        for(int j=i+1;j<n;j++)
            if(a[i]+a[j]==s)
                c++;
    return c;
}

int main()
{
    int a[]={1,5,7,-1,5};
    int n=sizeof(a)/sizeof(a[0]);
    int s=6;
    cout<<"count of pair is "<<C(a,n,s);
    return 0;
}
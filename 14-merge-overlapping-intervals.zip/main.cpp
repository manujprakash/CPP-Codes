#include <bits/stdc++.h>
using namespace std;

struct Int
{
    int start,end;
};

bool compareInt(Int i1, Int i2)
{
    return (i1.start < i2.start);
}

void mergeInt(Int a[],int n)
{
    if (n <= 0)
        return;
 
    stack<Int> s;
 
    sort(a,a+n,compareInt);
    s.push(a[0]);
 
    for (int i=1;i<n;i++)
    {

        Int top = s.top();
 

        if (top.end < a[i].start)
            s.push(a[i]);

        else if (top.end < a[i].end)
        {
            top.end=a[i].end;
            s.pop();
            s.push(top);
        }
    }

    cout << "\n The Merged Intervals are: ";
    while (!s.empty()) {
        Int t = s.top();
        cout << "[" << t.start << "," << t.end << "] ";
        s.pop();
    }
    return;
}
 
int main()
{
    Int a[]= { { 6, 8 }, { 1, 9 }, { 2, 4 }, { 4, 7 } };
    int n = sizeof(a) / sizeof(a[0]);
    mergeInt(a,n);
    return 0;
}
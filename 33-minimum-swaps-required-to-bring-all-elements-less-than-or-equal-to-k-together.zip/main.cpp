#include <iostream>
using namespace std;
 
int S(int*a,int n,int k) 
{

    int c=0;
    for(int i=0;i<n;++i)
        if(a[i]<=k)
            ++c;
     

    int b=0;
    for(int i=0;i<c;++i)
        if(a[i]>k)
            ++b;
     

    int ans=b;
    for(int i=0,j=c;j<n;++i,++j)
    {
         

        if (a[i]>k)
            --b;

        if (a[j]>k)
            ++b;
         

        ans=min(ans,b);
    }
    return ans;
}
 

int main() 
{
     
    int a[]={2,1,5,6,3};
    int n=sizeof(a)/sizeof(a[0]);
    int k=3;
    cout<<S(a,n,k)<<"\n";
    
    int a1[]={2,7,9,5,8,7,4};
    n=sizeof(a1)/sizeof(a1[0]);
    k=5;
    cout<<S(a1,n,k);
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
 

void S(int n,bool prime[],bool primesq[],int a[])
{
    for(int i=2;i<=n;i++)
        prime[i]=true;
 
    for(int i=0;i<=(n*n+1);i++)
        primesq[i]=false;
 
   
    prime[1]=false;
 
    for(int p=2;p*p<=n;p++) 
    {
     
        if(prime[p]==true) 
        {
           
            for(int i=p*2;i<=n;i+=p)
                prime[i]=false;
        }
    }
 
    int j=0;
    for(int p=2;p<=n;p++) 
    {
        if(prime[p]) 
        {
         
            a[j]=p;
 
            primesq[p*p]=true;
            j++;
        }
    }
}
 

int countDiv(int n)
{

    if(n==1)
        return 1;
 
    bool prime[n+1],primesq[n*n+1];
 
    int a[n];
 

    S(n,prime,primesq,a);
 

    int ans=1;
 

    for(int i=0;;i++) 
    {
 

        if(a[i]*a[i]*a[i]>n)
            break;
 
 
        int cnt=1;

        while(n%a[i]==0)
        {
            n=n/a[i];
            cnt=cnt+1;
        }
 

        ans=ans*cnt;
    }
 

    if(prime[n])
        ans=ans*2;
 

    else if(primesq[n])
        ans=ans*3;
 
  
    else if(n!=1)
        ans=ans*4;
 
    return ans; 
}
 

int sumo(int n)
{
    
    int res=1;
    for(int i=2;i<=sqrt(n);i++) 
    {
 
        int count=0,curr_sum=1;
        int curr_term=1;
        while(n%i==0) 
        {
            count++;
            n=n/i;
 
            curr_term*=i;
            curr_sum+=curr_term;
        }
 
        res*=curr_sum;
    }
 

    if(n>=2)
        res*=(1+n);
 
    return res;
}
 

bool checkA(int n)
{
    int count=countDiv(n);
    int sum=sumo(n);
 
    return(sum%count==0);
}
 

int main()
{
    int n=6;
    (checkA(n))?(cout<<"Yes"):(cout<<"No");
    return 0;
}